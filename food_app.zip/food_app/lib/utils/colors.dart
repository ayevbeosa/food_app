import 'package:flutter/material.dart';

const Color kPrimaryColor = Colors.green;
const kBackgroundColor = Color(0xFFF5F7FA);
const kSearchBarBackgroundColor = Color(0xFFF3F5F5);
const kSearchBarTextColor = Color(0xFFABADAD);
Color kShimmerBaseColor = Colors.grey.shade300;
Color kShimmerHighlightColor = Colors.grey.shade100;
