class Search {
  late String order;
  late String rating;
  late String noOfReviews;
  late String price;
  late String restaurantName;

  Search({
    required this.order,
    required this.rating,
    required this.noOfReviews,
    required this.price,
    required this.restaurantName,
  });
}
