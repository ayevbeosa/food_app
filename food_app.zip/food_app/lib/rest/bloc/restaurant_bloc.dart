import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:food_app/models/restaurants_response.dart';
import 'package:food_app/rest/api/api_repository.dart';
import 'package:food_app/rest/api/api_result.dart';
import 'package:food_app/rest/api/network_exceptions.dart';
import 'package:food_app/rest/api/result_state.dart';
import 'package:food_app/rest/event/restaurant_event.dart';

class RestaurantBloc
    extends Bloc<RestaurantEvent, ResultState<RestaurantsResponse>> {
  final ApiRepository _apiRepository;

  RestaurantBloc(this._apiRepository) : super(Idle());

  @override
  Stream<ResultState<RestaurantsResponse>> mapEventToState(
    RestaurantEvent event,
  ) async* {
    yield ResultState.loading();

    if (event is FetchAllRestaurants) {
      ApiResult<RestaurantsResponse> apiResult =
          await _apiRepository.fetchAllRestaurants();

      yield* apiResult.when(
        success: (RestaurantsResponse data) async* {
          yield ResultState.data(data: data);
        },
        failure: (NetworkExceptions error) async* {
          yield ResultState.error(ne: error);
        },
      );
    }
  }
}
