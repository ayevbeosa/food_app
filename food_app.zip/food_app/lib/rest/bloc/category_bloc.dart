import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:food_app/models/category_response.dart';
import 'package:food_app/rest/api/api_repository.dart';
import 'package:food_app/rest/api/api_result.dart';
import 'package:food_app/rest/api/network_exceptions.dart';
import 'package:food_app/rest/api/result_state.dart';
import 'package:food_app/rest/event/category_event.dart';

class CategoryBloc extends Bloc<CategoryEvent, ResultState<CategoryResponse>> {
  late ApiRepository _apiRepository;

  CategoryBloc(this._apiRepository) : super(Idle());

  @override
  Stream<ResultState<CategoryResponse>> mapEventToState(
    CategoryEvent event,
  ) async* {
    yield ResultState.loading();

    if (event is FetchAllCategories) {
      ApiResult<CategoryResponse> apiResult =
          await _apiRepository.fetchAllCategories();

      yield* apiResult.when(
        success: (CategoryResponse data) async* {
          yield ResultState.data(data: data);
        },
        failure: (NetworkExceptions networkExceptions) async* {
          yield ResultState.error(ne: networkExceptions);
        },
      );
    }
  }
}
