// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'baskets_dao.dart';

// **************************************************************************
// DaoGenerator
// **************************************************************************

mixin _$BasketsDaoMixin on DatabaseAccessor<AppDatabase> {
  $OptionsTable get options => attachedDatabase.options;
  $AdditionsTable get additions => attachedDatabase.additions;
  $BasketsTable get baskets => attachedDatabase.baskets;
}
