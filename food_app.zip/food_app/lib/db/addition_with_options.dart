import 'package:food_app/db/app_database.dart';

class AdditionWithOptions {
  final Addition additions;
  final List<Option> optionItems;

  AdditionWithOptions(this.additions, this.optionItems);
}
